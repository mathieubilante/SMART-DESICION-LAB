// Explainable AI Engine for academic predictions

interface StudentPerformance {
  grades: number[]
  credits: number[]
  targetGrades?: number[]
}

interface Prediction {
  overallGPA: number
  riskLevel: "low" | "medium" | "high"
  successChance: number
  recommendations: string[]
  explanation: string
}

export function predictAcademicPerformance(performance: StudentPerformance): Prediction {
  const { grades, credits, targetGrades } = performance

  // Calculate weighted GPA (0-20 scale converted to 0-4)
  const totalCredits = credits.reduce((a, b) => a + b, 0)
  const weightedSum = grades.reduce((sum, grade, idx) => sum + grade * credits[idx], 0)
  const gpa = weightedSum / totalCredits / 5 // Convert from 0-20 to 0-4 scale

  // Analyze grade distribution
  const avgGrade = grades.reduce((a, b) => a + b, 0) / grades.length
  const gradeVariance = grades.reduce((sum, g) => sum + Math.pow(g - avgGrade, 2), 0) / grades.length
  const standardDeviation = Math.sqrt(gradeVariance)

  // Determine risk level
  let riskLevel: "low" | "medium" | "high"
  if (avgGrade >= 14) riskLevel = "low"
  else if (avgGrade >= 10) riskLevel = "medium"
  else riskLevel = "high"

  // Calculate success chance (probability of maintaining or improving)
  let successChance = 0
  if (riskLevel === "low") successChance = 0.85
  else if (riskLevel === "medium") successChance = 0.65
  else successChance = 0.4

  // Generate recommendations
  const recommendations: string[] = []

  if (standardDeviation > 3) {
    recommendations.push("Stabilisez vos performances - grandes variations détectées")
  }

  const poorPerformances = grades.filter((g) => g < 10).length
  if (poorPerformances > 0) {
    recommendations.push(`Renforcez vos ${poorPerformances} matière(s) en difficulté`)
  }

  if (avgGrade < 12) {
    recommendations.push("Augmentez votre temps d'étude général")
    recommendations.push("Demandez du tutorat ou du soutien académique")
  }

  if (targetGrades) {
    const improvementNeeded = targetGrades.filter((t, i) => t && grades[i] < t - 1).length
    if (improvementNeeded > 0) {
      recommendations.push(`Fokus sur les ${improvementNeeded} matière(s) avec objectif ambitieux`)
    }
  }

  if (recommendations.length === 0) {
    recommendations.push("Continuez vos efforts - vos performances sont bonnes")
    recommendations.push("Explorez des cours avancés pour approfondir vos connaissances")
  }

  // Generate explanation
  const explanation = `
    Votre moyenne actuelle est de ${avgGrade.toFixed(2)}/20. 
    ${standardDeviation > 3 ? `Vos notes varient beaucoup (écart-type: ${standardDeviation.toFixed(2)}).` : `Vos performances sont relativement stables.`}
    ${riskLevel === "low" ? "Excellent travail - vous êtes bien positionné." : ""}
    ${riskLevel === "medium" ? "Performance satisfaisante, mais des améliorations sont possibles." : ""}
    ${riskLevel === "high" ? "Attention requise - des efforts supplémentaires sont nécessaires." : ""}
  `

  return {
    overallGPA: gpa,
    riskLevel,
    successChance: Math.round(successChance * 100),
    recommendations: [...new Set(recommendations)].slice(0, 5), // Remove duplicates, max 5
    explanation: explanation.trim(),
  }
}
