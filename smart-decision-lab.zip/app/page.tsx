"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase-client"
import Link from "next/link"
import { BookOpen, BarChart3, Brain, ArrowRight } from "lucide-react"

export default function Home() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = getSupabaseClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      setUser(session?.user || null)
      setLoading(false)
    }
    checkAuth()
  }, [supabase])

  if (loading) return <div className="flex items-center justify-center h-screen">Chargement...</div>

  if (user) {
    router.push("/dashboard")
    return null
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-background to-card">
      {/* Navigation */}
      <nav className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-primary" />
            <span className="text-2xl font-bold text-primary">SDL</span>
          </div>
          <div className="flex gap-4">
            <Link href="/login" className="px-4 py-2 text-foreground hover:text-primary transition">
              Connexion
            </Link>
            <Link
              href="/signup"
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-opacity-90 transition"
            >
              S'inscrire
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl font-bold text-foreground mb-6 text-balance">
              Prenez les meilleures décisions académiques
            </h1>
            <p className="text-xl text-muted-foreground mb-8 text-pretty">
              SDL utilise l'IA explicable pour analyser votre parcours, prédire vos performances et vous recommander les
              meilleurs chemins d'apprentissage.
            </p>
            <Link
              href="/signup"
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-3 rounded-lg hover:bg-opacity-90 transition text-lg font-semibold"
            >
              Commencer maintenant <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card border border-border rounded-lg p-6 flex flex-col items-center text-center">
              <BookOpen className="w-12 h-12 text-accent mb-3" />
              <h3 className="font-semibold mb-2">Suivi Académique</h3>
              <p className="text-sm text-muted-foreground">Enregistrez vos matières et performances</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-6 flex flex-col items-center text-center">
              <Brain className="w-12 h-12 text-accent mb-3" />
              <h3 className="font-semibold mb-2">IA Explicable</h3>
              <p className="text-sm text-muted-foreground">Comprendre chaque prédiction</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-6 flex flex-col items-center text-center">
              <BarChart3 className="w-12 h-12 text-accent mb-3" />
              <h3 className="font-semibold mb-2">Analytics</h3>
              <p className="text-sm text-muted-foreground">Visualisez vos progrès en détail</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-6 flex flex-col items-center text-center">
              <ArrowRight className="w-12 h-12 text-accent mb-3" />
              <h3 className="font-semibold mb-2">Recommandations</h3>
              <p className="text-sm text-muted-foreground">Décisions guidées par l'IA</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
