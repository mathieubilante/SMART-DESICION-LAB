"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase-client"
import { Brain } from "lucide-react"

interface Subject {
  id?: string
  name: string
  credits: number
  grade: number
  targetGrade?: number
}

export default function Subjects() {
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [numSubjects, setNumSubjects] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = getSupabaseClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      if (!session) {
        router.push("/login")
      } else {
        setUser(session.user)
        const num = Number.parseInt(sessionStorage.getItem("numSubjects") || "0", 10)
        setNumSubjects(num)
        setSubjects(
          Array(num)
            .fill(null)
            .map(() => ({ name: "", credits: 3, grade: 0 })),
        )
      }
    }
    checkAuth()
  }, [supabase, router])

  const updateSubject = (index: number, field: string, value: any) => {
    const updated = [...subjects]
    updated[index] = { ...updated[index], [field]: value }
    setSubjects(updated)
  }

  const handleSave = async () => {
    setLoading(true)
    setError("")

    try {
      // Validate subjects
      if (!subjects.every((s) => s.name.trim() && s.grade >= 0 && s.grade <= 20)) {
        throw new Error("Tous les champs sont requis et la note doit être entre 0 et 20")
      }

      // Save to database
      const { error: saveError } = await supabase.from("subjects").insert(
        subjects.map((s) => ({
          student_id: user.id,
          name: s.name,
          credits: s.credits,
          grade: s.grade,
          target_grade: s.targetGrade || s.grade,
          created_at: new Date().toISOString(),
        })),
      )

      if (saveError) throw saveError

      sessionStorage.removeItem("numSubjects")
      router.push("/dashboard")
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (!user || numSubjects === 0) return null

  return (
    <main className="min-h-screen bg-gradient-to-br from-background to-card">
      <div className="border-b border-border sticky top-0 z-50 bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-primary" />
            <span className="text-2xl font-bold text-primary">SDL</span>
          </div>
          <p className="text-sm text-muted-foreground">
            {subjects.filter((s) => s.name.trim()).length} / {numSubjects} matières
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="bg-card border border-border rounded-lg p-8">
          <h1 className="text-3xl font-bold mb-2">Entrez vos matières et performances</h1>
          <p className="text-muted-foreground mb-8">
            Remplissez les informations pour chacune de vos {numSubjects} matière(s).
          </p>

          {error && <div className="bg-destructive/10 text-destructive p-4 rounded-lg mb-6">{error}</div>}

          <div className="space-y-4 mb-8">
            {subjects.map((subject, idx) => (
              <div key={idx} className="border border-border rounded-lg p-4 bg-background">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <input
                    type="text"
                    placeholder="Nom de la matière"
                    value={subject.name}
                    onChange={(e) => updateSubject(idx, "name", e.target.value)}
                    className="border border-border rounded px-3 py-2 bg-card focus:ring-2 focus:ring-primary outline-none"
                  />
                  <input
                    type="number"
                    min="1"
                    max="6"
                    placeholder="Crédits"
                    value={subject.credits}
                    onChange={(e) => updateSubject(idx, "credits", Number.parseInt(e.target.value) || 0)}
                    className="border border-border rounded px-3 py-2 bg-card focus:ring-2 focus:ring-primary outline-none"
                  />
                  <input
                    type="number"
                    min="0"
                    max="20"
                    step="0.5"
                    placeholder="Note actuelle"
                    value={subject.grade || ""}
                    onChange={(e) => updateSubject(idx, "grade", Number.parseFloat(e.target.value) || 0)}
                    className="border border-border rounded px-3 py-2 bg-card focus:ring-2 focus:ring-primary outline-none"
                  />
                  <input
                    type="number"
                    min="0"
                    max="20"
                    step="0.5"
                    placeholder="Objectif (optionnel)"
                    value={subject.targetGrade || ""}
                    onChange={(e) => updateSubject(idx, "targetGrade", Number.parseFloat(e.target.value) || undefined)}
                    className="border border-border rounded px-3 py-2 bg-card focus:ring-2 focus:ring-primary outline-none"
                  />
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={handleSave}
            disabled={loading}
            className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:bg-opacity-90 transition disabled:opacity-50"
          >
            {loading ? "Sauvegarde..." : "Sauvegarder et accéder au tableau de bord"}
          </button>
        </div>
      </div>
    </main>
  )
}
