"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase-client"
import Link from "next/link"
import { Brain } from "lucide-react"

const DISCIPLINES = [
  "IABD - Ingénierie Analyse et Big Data",
  "Génie Électrique",
  "Génie Informatique",
  "Logistique et Transport",
  "Génie Mécanique",
  "Génie Civil",
  "Autre",
]

export default function SignUp() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [discipline, setDiscipline] = useState("")
  const [academicBackground, setAcademicBackground] = useState("")
  const [futureGoals, setFutureGoals] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const supabase = getSupabaseClient()

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      // Sign up user
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || window.location.origin,
        },
      })

      if (authError) throw authError
      if (!user) throw new Error("Erreur lors de la création du compte")

      // Create student profile
      const { error: profileError } = await supabase.from("students").insert([
        {
          id: user.id,
          email,
          full_name: fullName,
          discipline,
          academic_background: academicBackground,
          future_goals: futureGoals,
          created_at: new Date().toISOString(),
        },
      ])

      if (profileError) throw profileError

      router.push("/onboarding")
    } catch (err: any) {
      setError(err.message || "Erreur lors de l'inscription")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-background to-card flex flex-col">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-2">
          <Brain className="w-8 h-8 text-primary" />
          <Link href="/" className="text-2xl font-bold text-primary">
            SDL
          </Link>
        </div>
      </div>

      {/* Form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          <div className="bg-card border border-border rounded-lg p-8">
            <h1 className="text-3xl font-bold mb-2">Créer votre compte</h1>
            <p className="text-muted-foreground mb-6">Rejoignez SDL pour optimiser votre parcours académique</p>

            {error && <div className="bg-destructive/10 text-destructive p-4 rounded-lg mb-6">{error}</div>}

            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Nom complet</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full border border-border rounded-lg px-4 py-2 bg-background focus:ring-2 focus:ring-primary outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-border rounded-lg px-4 py-2 bg-background focus:ring-2 focus:ring-primary outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Mot de passe</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full border border-border rounded-lg px-4 py-2 bg-background focus:ring-2 focus:ring-primary outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Filière</label>
                <select
                  value={discipline}
                  onChange={(e) => setDiscipline(e.target.value)}
                  className="w-full border border-border rounded-lg px-4 py-2 bg-background focus:ring-2 focus:ring-primary outline-none"
                  required
                >
                  <option value="">Sélectionnez votre filière</option>
                  {DISCIPLINES.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Parcours académique antérieur</label>
                <textarea
                  value={academicBackground}
                  onChange={(e) => setAcademicBackground(e.target.value)}
                  placeholder="Décrivez vos études précédentes..."
                  className="w-full border border-border rounded-lg px-4 py-2 bg-background focus:ring-2 focus:ring-primary outline-none resize-none"
                  rows={3}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Objectifs futurs</label>
                <textarea
                  value={futureGoals}
                  onChange={(e) => setFutureGoals(e.target.value)}
                  placeholder="Quels sont vos objectifs académiques et professionnels?"
                  className="w-full border border-border rounded-lg px-4 py-2 bg-background focus:ring-2 focus:ring-primary outline-none resize-none"
                  rows={3}
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-primary-foreground py-2 rounded-lg font-semibold hover:bg-opacity-90 transition disabled:opacity-50"
              >
                {loading ? "Création en cours..." : "S'inscrire"}
              </button>
            </form>

            <p className="text-center text-muted-foreground mt-6">
              Vous avez déjà un compte?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Connexion
              </Link>
            </p>
          </div>
        </div>
      </div>
    </main>
  )
}
