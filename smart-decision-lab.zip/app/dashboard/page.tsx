"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase-client"
import { predictAcademicPerformance } from "@/lib/ai-engine"
import { Brain, LogOut, BarChart3, TrendingUp, AlertCircle, CheckCircle, BookOpen } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "recharts"

interface Subject {
  id: string
  name: string
  credits: number
  grade: number
  target_grade?: number
}

export default function Dashboard() {
  const [user, setUser] = useState<any>(null)
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [prediction, setPrediction] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = getSupabaseClient()

  useEffect(() => {
    const loadData = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()
        if (!session) {
          router.push("/login")
          return
        }
        setUser(session.user)

        // Load subjects
        const { data: subjectsData, error: subjectsError } = await supabase
          .from("subjects")
          .select("*")
          .eq("student_id", session.user.id)
          .order("created_at", { ascending: false })

        if (subjectsError) throw subjectsError

        setSubjects(subjectsData || [])

        // Calculate predictions
        if (subjectsData && subjectsData.length > 0) {
          const pred = predictAcademicPerformance({
            grades: subjectsData.map((s) => s.grade),
            credits: subjectsData.map((s) => s.credits),
            targetGrades: subjectsData.map((s) => s.target_grade),
          })
          setPrediction(pred)
        }
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [supabase, router])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  if (loading) return <div className="flex items-center justify-center h-screen">Chargement...</div>
  if (!user || !prediction) return null

  const avgGrade = (subjects.reduce((sum, s) => sum + s.grade, 0) / subjects.length).toFixed(2)
  const chartData = subjects.map((s) => ({
    name: s.name.substring(0, 10),
    grade: s.grade,
    target: s.target_grade || s.grade,
  }))

  const riskColors = {
    low: "bg-green-100 border-green-300 text-green-900",
    medium: "bg-yellow-100 border-yellow-300 text-yellow-900",
    high: "bg-red-100 border-red-300 text-red-900",
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-background to-card">
      {/* Header */}
      <div className="border-b border-border sticky top-0 z-50 bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-primary" />
            <span className="text-2xl font-bold text-primary">SDL</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">{user.email}</span>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 text-destructive hover:bg-destructive/10 rounded-lg transition"
            >
              <LogOut className="w-4 h-4" />
              Déconnexion
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* KPI Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-muted-foreground text-sm">Moyenne générale</span>
              <BookOpen className="w-5 h-5 text-accent" />
            </div>
            <p className="text-3xl font-bold">{avgGrade}/20</p>
            <p className="text-xs text-muted-foreground mt-2">Sur {subjects.length} matières</p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-muted-foreground text-sm">Chance de réussite</span>
              <TrendingUp className="w-5 h-5 text-primary" />
            </div>
            <p className="text-3xl font-bold">{prediction.successChance}%</p>
            <p className="text-xs text-muted-foreground mt-2">Probabilité d\'amélioration</p>
          </div>

          <div className={`rounded-lg p-6 border ${riskColors[prediction.riskLevel]}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-sm">Niveau de risque</span>
              {prediction.riskLevel === "low" && <CheckCircle className="w-5 h-5" />}
              {prediction.riskLevel === "medium" && <AlertCircle className="w-5 h-5" />}
              {prediction.riskLevel === "high" && <AlertCircle className="w-5 h-5" />}
            </div>
            <p className="text-3xl font-bold capitalize">{prediction.riskLevel}</p>
            <p className="text-xs mt-2 opacity-75">Analyse IA explicable</p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-muted-foreground text-sm">GPA (0-4)</span>
              <BarChart3 className="w-5 h-5 text-secondary" />
            </div>
            <p className="text-3xl font-bold">{prediction.overallGPA.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground mt-2">Moyenne pondérée</p>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Charts and Analysis */}
          <div className="lg:col-span-2 space-y-8">
            {/* Performance Chart */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">Performances par matière</h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 20]} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="grade" fill="var(--color-chart-1)" name="Note actuelle" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="target" fill="var(--color-chart-2)" name="Objectif" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Trend Chart */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6">Distribution des notes</h2>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={chartData}>
                  <PolarGrid stroke="var(--color-border)" />
                  <PolarAngleAxis dataKey="name" />
                  <PolarRadiusAxis angle={90} domain={[0, 20]} />
                  <Radar
                    name="Vos notes"
                    dataKey="grade"
                    stroke="var(--color-chart-1)"
                    fill="var(--color-chart-1)"
                    fillOpacity={0.6}
                  />
                  <Radar
                    name="Objectifs"
                    dataKey="target"
                    stroke="var(--color-chart-2)"
                    fill="var(--color-chart-2)"
                    fillOpacity={0.3}
                  />
                  <Legend />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Recommendations Sidebar */}
          <div className="space-y-6">
            {/* AI Explanation */}
            <div className="bg-primary/10 border border-primary/30 rounded-lg p-6">
              <h3 className="font-bold mb-3 flex items-center gap-2">
                <Brain className="w-5 h-5 text-primary" />
                Analyse IA explicable
              </h3>
              <p className="text-sm text-foreground leading-relaxed">{prediction.explanation}</p>
            </div>

            {/* Recommendations */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="font-bold mb-4">Recommandations personnalisées</h3>
              <ul className="space-y-3">
                {prediction.recommendations.map((rec: string, idx: number) => (
                  <li key={idx} className="flex gap-3 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Subject List */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="font-bold mb-4">Vos matières ({subjects.length})</h3>
              <div className="space-y-2">
                {subjects.map((s) => (
                  <div key={s.id} className="flex justify-between items-center text-sm p-2 rounded bg-background">
                    <span className="font-medium">{s.name}</span>
                    <span
                      className={`font-bold ${s.grade >= 14 ? "text-green-600" : s.grade >= 10 ? "text-yellow-600" : "text-red-600"}`}
                    >
                      {s.grade}/20
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
