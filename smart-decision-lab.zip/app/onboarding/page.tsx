"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase-client"
import { Brain } from "lucide-react"

export default function Onboarding() {
  const [numSubjects, setNumSubjects] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const supabase = getSupabaseClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      if (!session) {
        router.push("/login")
      } else {
        setUser(session.user)
      }
    }
    checkAuth()
  }, [supabase, router])

  const handleContinue = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const num = Number.parseInt(numSubjects, 10)
      if (num < 1 || num > 30) throw new Error("Entre 1 et 30 matières")

      // Store number of subjects for next step
      sessionStorage.setItem("numSubjects", numSubjects)
      router.push("/subjects")
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (!user) return null

  return (
    <main className="min-h-screen bg-gradient-to-br from-background to-card">
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-2">
          <Brain className="w-8 h-8 text-primary" />
          <span className="text-2xl font-bold text-primary">SDL</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-6 py-12">
        <div className="bg-card border border-border rounded-lg p-8">
          <h1 className="text-3xl font-bold mb-6">Configurez votre parcours</h1>
          <p className="text-muted-foreground mb-8">
            Commençons par définir le nombre de matières que vous suivez cette année.
          </p>

          {error && <div className="bg-destructive/10 text-destructive p-4 rounded-lg mb-6">{error}</div>}

          <form onSubmit={handleContinue} className="space-y-6">
            <div>
              <label className="block text-lg font-semibold mb-3">Combien de matières suivez-vous?</label>
              <input
                type="number"
                min="1"
                max="30"
                value={numSubjects}
                onChange={(e) => setNumSubjects(e.target.value)}
                className="w-full border-2 border-border rounded-lg px-4 py-3 text-lg bg-background focus:ring-2 focus:ring-primary outline-none"
                placeholder="Entrez un nombre entre 1 et 30"
                required
              />
              <p className="text-sm text-muted-foreground mt-2">
                Vous pourrez ajouter ou modifier vos matières à tout moment.
              </p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:bg-opacity-90 transition disabled:opacity-50 text-lg"
            >
              {loading ? "Chargement..." : "Continuer"}
            </button>
          </form>
        </div>
      </div>
    </main>
  )
}
