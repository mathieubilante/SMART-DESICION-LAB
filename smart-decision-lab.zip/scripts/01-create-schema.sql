-- Create students table
CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  discipline TEXT NOT NULL,
  academic_background TEXT,
  future_goals TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create subjects table (courses per student)
CREATE TABLE subjects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  code TEXT,
  credits INTEGER,
  semester TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create performances table (grades and progress)
CREATE TABLE performances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  continuous_assessment DECIMAL(5,2),
  midterm_exam DECIMAL(5,2),
  final_exam DECIMAL(5,2),
  practical_work DECIMAL(5,2),
  final_grade DECIMAL(5,2),
  status TEXT DEFAULT 'in_progress',
  recorded_date TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create predictions table (AI predictions)
CREATE TABLE predictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id UUID,
  prediction_type TEXT NOT NULL,
  success_probability DECIMAL(5,2),
  risk_level TEXT,
  recommendation TEXT,
  explanation TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create analytics table (aggregated insights)
CREATE TABLE analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  gpa DECIMAL(5,2),
  completion_rate DECIMAL(5,2),
  at_risk_count INTEGER,
  strong_subjects TEXT[],
  weak_subjects TEXT[],
  overall_trajectory TEXT,
  last_calculated TIMESTAMP DEFAULT NOW()
);

-- Enable RLS (Row Level Security)
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE performances ENABLE ROW LEVEL SECURITY;
ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policies - Students can only see their own data
CREATE POLICY students_read_policy ON students
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY students_update_policy ON students
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY subjects_policy ON subjects
  FOR ALL USING (student_id IN (
    SELECT id FROM students WHERE user_id = auth.uid()
  ));

CREATE POLICY performances_policy ON performances
  FOR ALL USING (student_id IN (
    SELECT id FROM students WHERE user_id = auth.uid()
  ));

CREATE POLICY predictions_policy ON predictions
  FOR ALL USING (student_id IN (
    SELECT id FROM students WHERE user_id = auth.uid()
  ));

CREATE POLICY analytics_policy ON analytics
  FOR ALL USING (student_id IN (
    SELECT id FROM students WHERE user_id = auth.uid()
  ));

-- Create indexes for performance
CREATE INDEX idx_students_user_id ON students(user_id);
CREATE INDEX idx_subjects_student_id ON subjects(student_id);
CREATE INDEX idx_performances_student_id ON performances(student_id);
CREATE INDEX idx_performances_subject_id ON performances(subject_id);
CREATE INDEX idx_predictions_student_id ON predictions(student_id);
CREATE INDEX idx_analytics_student_id ON analytics(student_id);
