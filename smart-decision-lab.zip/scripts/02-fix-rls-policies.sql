-- Activer RLS si ce n'est pas déjà fait
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE performances ENABLE ROW LEVEL SECURITY;
ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;

-- Supprimer les anciennes politiques s'il y en a
DROP POLICY IF EXISTS "allow_own_profile" ON students;
DROP POLICY IF EXISTS "allow_own_subjects" ON subjects;
DROP POLICY IF EXISTS "allow_own_performances" ON performances;
DROP POLICY IF EXISTS "allow_own_predictions" ON predictions;

-- Politiques pour students - chaque utilisateur ne peut voir/modifier que son propre profil
CREATE POLICY "allow_own_profile" ON students
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "allow_insert_own_profile" ON students
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Politiques pour subjects - chaque utilisateur ne peut voir que ses propres matières
CREATE POLICY "allow_own_subjects" ON subjects
  FOR ALL
  USING (student_id = (SELECT id FROM students WHERE user_id = auth.uid()))
  WITH CHECK (student_id = (SELECT id FROM students WHERE user_id = auth.uid()));

CREATE POLICY "allow_insert_own_subjects" ON subjects
  FOR INSERT
  WITH CHECK (student_id = (SELECT id FROM students WHERE user_id = auth.uid()));

-- Politiques pour performances
CREATE POLICY "allow_own_performances" ON performances
  FOR ALL
  USING (student_id = (SELECT id FROM students WHERE user_id = auth.uid()))
  WITH CHECK (student_id = (SELECT id FROM students WHERE user_id = auth.uid()));

CREATE POLICY "allow_insert_own_performances" ON performances
  FOR INSERT
  WITH CHECK (student_id = (SELECT id FROM students WHERE user_id = auth.uid()));

-- Politiques pour predictions
CREATE POLICY "allow_own_predictions" ON predictions
  FOR ALL
  USING (student_id = (SELECT id FROM students WHERE user_id = auth.uid()))
  WITH CHECK (student_id = (SELECT id FROM students WHERE user_id = auth.uid()));

CREATE POLICY "allow_insert_own_predictions" ON predictions
  FOR INSERT
  WITH CHECK (student_id = (SELECT id FROM students WHERE user_id = auth.uid()));
